# Quorum Live — Deep Research

Лёгкий Vercel-first multi-agent research app без тяжёлого Python-стека.

## Pipeline

1. Research planner (если доступен LLM) формирует дополнительные gaps для поиска.
2. 5 базовых поисковых направлений + до 3 planner-направлений.
3. Источники дедуплицируются, ранжируются по качеству и разнообразию доменов.
4. До 8 страниц проходят deep-read через Jina Reader.
5. Из прочитанных страниц извлекается до 4 новых ссылок для второго hop.
6. 3 независимых аналитических агента работают по общему evidence pack.
7. 2–4 adversarial-аудита: fact-check, contradiction/red-team, методология.
8. Финальный evidence-first synthesis с [S#] citations и явным uncertainty.

## Почему не встроены CrewAI / MetaGPT / LangGraph / Browser Use

Эти проекты полезны как источники паттернов, но добавление их целиком сделало бы маленький Vercel-проект тяжелее и усложнило бы deployment. Мы перенесли практики на уровень приложения:

- role-based agents и SOP-подобный workflow из MetaGPT/CrewAI;
- explicit deterministic orchestration и multi-hop state из LangGraph-style workflows;
- browser/deep-read tool idea из Browser Use;
- evidence-first retrieval idea из Needle;
- lightweight tools/skills modules и adversarial guardrails без framework dependency.

## APIs / env

Опционально задайте в Vercel:

- `KILO_JWT` или `KILO_API_KEY`
- `KILO_MODEL`
- `OPENROUTER_API_KEY`
- `OPENROUTER_MODEL`
- `TAVILY_API_KEY`
- `JINA_API_KEY`
- `BROWSER_USE_API_KEY` (необязательно; включает отдельный browser-agent lane)

Без ключей web-only режим использует Jina Search + DuckDuckGo fallback + Jina Reader и не симулирует выдуманный LLM-синтез.

## Deploy

Загрузите содержимое проекта в Vercel. `index.html` — статический frontend, `api/*.js` — Vercel Functions.

## Health check

`GET /api/health` показывает доступные capability-флаги без раскрытия секретов.
