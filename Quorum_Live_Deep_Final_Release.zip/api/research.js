const DEFAULT_MODEL = process.env.OPENROUTER_MODEL || 'openrouter/free';
const KILO_MODEL = process.env.KILO_MODEL || 'kilo-auto/free';
const SEARCH_TIMEOUT = 22000;
const READ_TIMEOUT = 18000;
const LLM_TIMEOUT = 38000;
const SKILLS = require('./skills');

const AGENTS = [
  { name: 'Алекс', role: 'Domain Scientist', system: 'Ты Алекс — Domain Scientist. Выделяешь проверяемые факты, механизмы, количественные данные и границы применимости. Приоритет — первичные источники и свежие данные.' },
  { name: 'Мара', role: 'Systems Engineer', system: 'Ты Мара — Systems Engineer. Анализируешь архитектуру, практическую реализуемость, зависимости, failure modes, масштабирование и альтернативы.' },
  { name: 'Элиас', role: 'Critical Reviewer', system: 'Ты Элиас — Critical Reviewer. Ищешь противоречия, слабые доказательства, альтернативные объяснения, скрытые предпосылки и риски второго порядка.' }
];

function json(res, code, body) {
  res.statusCode = code;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(body));
}

function clamp(s, n) { return String(s || '').slice(0, n); }
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function timeoutFetch(url, options = {}, ms = 25000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  return fetch(url, { ...options, signal: controller.signal }).finally(() => clearTimeout(timer));
}

function normalizeUrl(u) {
  try {
    const url = new URL(String(u || '').trim());
    if (!/^https?:$/.test(url.protocol)) return null;
    const host = url.hostname.toLowerCase();
    if (!host || host === 'localhost' || host.endsWith('.localhost') || host === 'metadata.google.internal' || host === '0.0.0.0' || host === '127.0.0.1' || host === '::1') return null;
    if (/^10\./.test(host) || /^192\.168\./.test(host) || /^169\.254\./.test(host) || /^172\.(1[6-9]|2\d|3[0-1])\./.test(host)) return null;
    return url.href;
  } catch { return null; }
}

function domainOf(url) {
  try { return new URL(url).hostname.toLowerCase().replace(/^www\./, ''); } catch { return ''; }
}

function parseJinaResults(raw) {
  const text = String(raw || '');
  const links = [];
  const md = /\[([^\]]{3,220})\]\((https?:\/\/[^)\s]+)\)/g;
  let m;
  while ((m = md.exec(text)) && links.length < 20) {
    const url = normalizeUrl(m[2]);
    if (url && !links.some(x => x.url === url)) links.push({ title: m[1].trim(), url });
  }
  const sourceLines = text.match(/URL Source:\s*(https?:\/\/[^\s]+)/g) || [];
  for (const line of sourceLines) {
    const url = normalizeUrl(line.replace(/^URL Source:\s*/i, ''));
    if (url && !links.some(x => x.url === url)) links.push({ title: url, url });
  }
  return links;
}

async function tavilySearch(query, key) {
  const r = await timeoutFetch('https://api.tavily.com/search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` },
    body: JSON.stringify({
      query,
      topic: 'general',
      search_depth: 'advanced',
      max_results: 8,
      include_answer: false,
      include_raw_content: true,
      include_favicon: false
    })
  }, SEARCH_TIMEOUT);
  if (!r.ok) throw new Error(`Tavily ${r.status}`);
  const d = await r.json();
  return (d.results || []).map((x, i) => ({
    id: `S${i + 1}`,
    title: x.title || x.url,
    url: x.url,
    snippet: x.content || '',
    content: x.raw_content || x.content || '',
    published: x.published_date || null,
    source: 'tavily'
  }));
}

async function jinaSearch(query, jinaKey) {
  const headers = { Accept: 'text/plain' };
  if (jinaKey) headers.Authorization = `Bearer ${jinaKey}`;
  const r = await timeoutFetch(`https://s.jina.ai/?q=${encodeURIComponent(query)}`, { headers }, SEARCH_TIMEOUT);
  if (!r.ok) throw new Error(`Jina Search ${r.status}`);
  const raw = await r.text();
  return parseJinaResults(raw).slice(0, 8).map((x, i) => ({
    id: `S${i + 1}`,
    title: x.title,
    url: x.url,
    snippet: raw.slice(0, 2200),
    content: raw.slice(0, 12000),
    source: 'jina'
  }));
}

async function duckSearch(query) {
  const r = await timeoutFetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`, { headers: { Accept: 'text/html' } }, SEARCH_TIMEOUT);
  if (!r.ok) throw new Error(`DuckDuckGo ${r.status}`);
  const html = await r.text();
  const out = [];
  const re = /result__a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
  let m;
  while ((m = re.exec(html)) && out.length < 8) {
    const rawUrl = m[1];
    const urlMatch = rawUrl.match(/uddg=([^&]+)/);
    const url = normalizeUrl(urlMatch ? decodeURIComponent(urlMatch[1]) : rawUrl);
    if (!url) continue;
    const title = m[2].replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').trim();
    if (!out.some(x => x.url === url)) out.push({ id: `S${out.length + 1}`, title: title || url, url, snippet: '', content: '', source: 'duckduckgo' });
  }
  return out;
}

async function browserUseResearch(query, key) {
  const base = 'https://api.browser-use.com/api/v3';
  const headers = { 'X-Browser-Use-API-Key': key, 'Content-Type': 'application/json' };
  const task = `Research task: ${query}. Browse the public web deeply. Find 3-5 useful sources, prioritizing primary/official/technical sources and recent material. For each source, return TITLE, URL, and a 2-4 sentence evidence-focused finding. Also note one contradiction or uncertainty. Do not invent URLs.`;
  const created = await timeoutFetch(`${base}/sessions`, { method:'POST', headers, body: JSON.stringify({ task, model:'bu-mini', max_cost_usd:0.05 }) }, 12000);
  if (!created.ok) throw new Error(`Browser Use ${created.status}`);
  const c = await created.json();
  const id = c.id || c.session_id;
  if (!id) throw new Error('Browser Use session id missing');
  const deadline = Date.now() + 40000;
  while (Date.now() < deadline) {
    const r = await timeoutFetch(`${base}/sessions/${encodeURIComponent(id)}`, { headers }, 12000);
    if (!r.ok) throw new Error(`Browser Use session ${r.status}`);
    const d = await r.json();
    const status = String(d.status || '').toLowerCase();
    if (['idle','stopped','timed_out','error','completed','failed'].includes(status)) {
      const output = d.output || d.result?.output || d.result || d.final_result || '';
      return { output: typeof output === 'string' ? output : JSON.stringify(output), id, status, liveUrl: d.live_url || null };
    }
    await sleep(2000);
  }
  return { output:'', id, status:'poll_timeout', liveUrl:null };
}

function browserMemoSources(output) {
  const text = String(output || '');
  const urls = [...new Set((text.match(/https?:\/\/[^\s)\]>]+/g) || []).map(u => normalizeUrl(u.replace(/[.,;]+$/, ''))).filter(Boolean))];
  return urls.slice(0, 5).map((url, i) => ({ id:`B${i+1}`, title:`Browser Use lead ${i+1}`, url, snippet:text.slice(0,1800), content:text.slice(0,5000), source:'browser-use' }));
}

async function readWithJina(url, jinaKey) {
  const headers = {
    Accept: 'text/markdown',
    'X-Respond-With': 'markdown',
    'X-Engine': 'auto',
    'X-No-Cache': 'true',
    'X-Max-Tokens': '4500',
    'X-Timeout': '18'
  };
  if (jinaKey) headers.Authorization = `Bearer ${jinaKey}`;
  const r = await timeoutFetch(`https://r.jina.ai/${url}`, { headers }, READ_TIMEOUT);
  if (!r.ok) throw new Error(`Reader ${r.status}`);
  return clamp(await r.text(), 10000);
}

function scoreSource(s) {
  const d = domainOf(s.url);
  const t = `${s.title || ''} ${s.snippet || ''}`.toLowerCase();
  let score = 0;
  if (/\.gov$|\.gov\.|\.edu$|\.edu\.|who\.int$|oecd\.org$|worldbank\.org$|europa\.eu$/.test(d)) score += 8;
  if (/arxiv\.org$|doi\.org$|nature\.com$|science\.org$|nejm\.org$|acm\.org$|ieee\.org$/.test(d)) score += 7;
  if (/github\.com$|gitlab\.com$/.test(d)) score += 3;
  if (/official|documentation|specification|report|paper|study|dataset|research|benchmark/.test(t)) score += 3;
  if (/2026|2025|latest|updated|current|release/.test(t)) score += 2;
  score += Math.min(3, Math.floor(String(s.content || s.snippet || '').length / 1800));
  return score;
}

function uniqRanked(groups, limit = 12) {
  const map = new Map();
  for (const group of groups) for (const s of (group || [])) {
    const url = normalizeUrl(s.url);
    if (!url) continue;
    const existing = map.get(url);
    const candidate = { ...s, url, domain: domainOf(url), quality: scoreSource(s) };
    if (!existing || candidate.quality > existing.quality) map.set(url, candidate);
  }
  const candidates = [...map.values()].sort((a, b) => b.quality - a.quality);
  const domains = new Map();
  const chosen = [];
  for (const s of candidates) {
    const count = domains.get(s.domain) || 0;
    if (count >= 2) continue;
    domains.set(s.domain, count + 1);
    chosen.push({ ...s, id: `S${chosen.length + 1}` });
    if (chosen.length >= limit) break;
  }
  return chosen;
}

function extractLinks(markdown, existingUrls) {
  const seen = new Set(existingUrls);
  const out = [];
  const re = /\[[^\]]{2,180}\]\((https?:\/\/[^)\s]+)\)/g;
  let m;
  while ((m = re.exec(String(markdown || ''))) && out.length < 20) {
    const url = normalizeUrl(m[1]);
    if (!url || seen.has(url) || url.includes('s.jina.ai') || url.includes('r.jina.ai')) continue;
    seen.add(url);
    out.push({ title: url, url, snippet: '', content: '', source: 'deep-link' });
  }
  return out;
}

function evidencePack(sources, maxPer = 4200, totalMax = 42000) {
  let total = 0;
  const parts = [];
  for (const s of sources) {
    const part = `### [${s.id}] ${s.title}\nURL: ${s.url}\n${clamp(s.content || s.snippet, maxPer)}`;
    if (total + part.length > totalMax && parts.length >= 6) break;
    parts.push(part);
    total += part.length;
  }
  return parts.join('\n\n');
}

async function callLLM({ prompt, system, kiloKey, openRouterKey, maxTokens = 2800 }) {
  if (kiloKey) {
    try {
      const r = await timeoutFetch('https://api.kilo.ai/api/gateway/chat/completions', {
        method: 'POST',
        headers: { Authorization: `Bearer ${kiloKey}`, 'Content-Type': 'application/json', 'x-kilocode-mode': 'ask' },
        body: JSON.stringify({ model: KILO_MODEL, messages: [{ role: 'system', content: system }, { role: 'user', content: prompt }], temperature: 0.15, max_tokens: maxTokens })
      }, LLM_TIMEOUT);
      if (r.ok) {
        const d = await r.json();
        const t = d.choices?.[0]?.message?.content || '';
        if (t.trim()) return { text: t.trim(), mode: 'kilo' };
      }
    } catch {}
  }
  if (openRouterKey) {
    try {
      const r = await timeoutFetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: { Authorization: `Bearer ${openRouterKey}`, 'Content-Type': 'application/json', 'HTTP-Referer': 'https://vercel.app', 'X-Title': 'Quorum Live' },
        body: JSON.stringify({ model: DEFAULT_MODEL, messages: [{ role: 'system', content: system }, { role: 'user', content: prompt }], temperature: 0.15, max_tokens: maxTokens })
      }, LLM_TIMEOUT);
      if (r.ok) {
        const d = await r.json();
        const t = d.choices?.[0]?.message?.content || '';
        if (t.trim()) return { text: t.trim(), mode: 'openrouter' };
      }
    } catch {}
  }
  return { text: '', mode: 'web-only' };
}

function sourceList(sources) {
  return sources.map(s => `- [${s.id}] ${s.title} — ${s.url}`).join('\n');
}

function sanitizeCitations(text, sources) {
  const valid = new Set(sources.map(s => s.id));
  return String(text || '').replace(/\[S(\d+)\]/g, (m, n) => valid.has(`S${n}`) ? m : '');
}

function fallbackSynthesis(query, sources, agents, critics) {
  return `# Quorum Live — Deep Research\n\n## Запрос\n${query}\n\n## Режим\nWeb-only evidence dossier: LLM-ключ не был доступен, поэтому приложение не симулирует выдуманный мультиагентный синтез.\n\n## Что реально проверено\nMulti-hop web research: 5 независимых направлений поиска, ранжирование источников по качеству и разнообразию доменов, глубокое чтение найденных страниц и второй hop по ссылкам из этих материалов.\n\n## Собранные наблюдения\n${agents.filter(x => x.text).map(a => `### ${a.name} — ${a.role}\n${a.text}`).join('\n\n') || 'LLM-аналитики недоступны; ниже остаётся проверяемый пакет evidence.'}\n\n## Критические замечания\n${critics.filter(Boolean).join('\n\n') || 'Автоматический критический audit LLM не запускался.'}\n\n## Источники\n${sourceList(sources)}\n\n> Данные без LLM-синтеза показаны намеренно, чтобы не создавать видимость уверенного вывода там, где модель недоступна.`;
}

function getBody(req) {
  if (!req.body) return {};
  if (typeof req.body === 'object') return req.body;
  try { return JSON.parse(req.body); } catch { return {}; }
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return json(res, 405, { error: 'POST only' });
  const started = Date.now();
  try {
    const body = getBody(req);
    const query = clamp(body.query, 500).trim();
    if (!query) return json(res, 400, { error: 'Введите запрос' });

    const kiloKey = clamp(body.kiloKey || process.env.KILO_JWT || process.env.KILO_API_KEY, 700);
    const openRouterKey = clamp(body.openRouterKey || process.env.OPENROUTER_API_KEY, 700);
    const jinaKey = clamp(body.jinaKey || process.env.JINA_API_KEY, 700);
    const tavilyKey = clamp(body.tavilyKey || process.env.TAVILY_API_KEY, 700);

    const queries = [
      `${query} current state latest facts primary sources`,
      `${query} official documentation research paper government company data`,
      `${query} recent developments 2025 2026 evidence statistics benchmarks`,
      `${query} criticism limitations risks contradictions independent analysis`,
      `${query} implementation market economics alternatives practical examples`
    ];

    const searchStarted = Date.now();
    const browserKey = clamp(body.browserUseKey || process.env.BROWSER_USE_API_KEY, 700);
    let planner = null;
    if (kiloKey || openRouterKey) {
      planner = await callLLM({
        system: `Ты research planner. ${SKILLS.browser_research} Построй только поисковую стратегию: выдели 3–5 узких gaps/questions, которые чаще всего не покрывает обычный поиск. Не отвечай на тему.`,
        prompt: `Запрос: ${query}\n\nДай 3–5 коротких дополнительных поисковых направлений.`,
        kiloKey, openRouterKey, maxTokens: 700
      });
    }
    const plannedQueries = planner?.text
      ? planner.text.split(/\n+/).map(x => x.replace(/^[-*\d.)\s]+/, '').trim()).filter(Boolean).slice(0, 3).map(x => `${query} ${x}`)
      : [];
    const allQueries = [...queries, ...plannedQueries];

    const browserPromise = browserKey ? browserUseResearch(query, browserKey) : Promise.resolve(null);
    const searchResults = await Promise.allSettled(allQueries.map(q => tavilyKey ? tavilySearch(q, tavilyKey) : jinaSearch(q, jinaKey)));
    const groups = searchResults.map((r, i) => r.status === 'fulfilled' ? r.value.map(x => ({ ...x, query: allQueries[i] })) : []);
    for (let i = 0; i < groups.length; i++) {
      if (!groups[i].length && !tavilyKey) {
        try { groups[i] = (await duckSearch(allQueries[i])).map(x => ({ ...x, query: allQueries[i] })); } catch {}
      }
    }
    const browserResult = await browserPromise.catch(() => null);
    const browserLeads = browserMemoSources(browserResult?.output || '');
    const discovered = uniqRanked([ ...groups, browserLeads ], 12);

    const readStarted = Date.now();
    const firstWave = discovered.slice(0, 8);
    const firstReads = await Promise.allSettled(firstWave.map(s => readWithJina(s.url, jinaKey)));
    firstReads.forEach((r, i) => { if (r.status === 'fulfilled' && r.value) { firstWave[i].content = r.value; firstWave[i].deepRead = true; } });

    const existing = new Set(discovered.map(x => x.url));
    const secondHopCandidates = [];
    for (const s of firstWave) secondHopCandidates.push(...extractLinks(s.content, existing));
    const secondHop = uniqRanked([secondHopCandidates], 4);
    const secondReads = await Promise.allSettled(secondHop.map(s => readWithJina(s.url, jinaKey)));
    secondReads.forEach((r, i) => { if (r.status === 'fulfilled' && r.value) { secondHop[i].content = r.value; secondHop[i].deepRead = true; } });

    const evidenceSources = uniqRanked([firstWave, secondHop], 12);
    const evidence = evidencePack(evidenceSources);
    const readMs = Date.now() - readStarted;

    const agentStarted = Date.now();
    const agentResults = await Promise.all(AGENTS.map(a => callLLM({
      system: `${a.system} ${SKILLS.evidence_first} ${SKILLS.browser_research}`,
      prompt: `Запрос: ${query}\n\nЗадача: подготовь независимый аналитический memo. Найди то, что другие агенты могут пропустить.\n\nEVIDENCE:\n${evidence}`,
      kiloKey, openRouterKey, maxTokens: 2800
    })));
    const agentPack = agentResults.map((r, i) => `### ${AGENTS[i].name} — ${AGENTS[i].role}\n${r.text || 'LLM unavailable.'}`).join('\n\n');

    const requestedRounds = Math.min(Math.max(Number(body.rounds) || 3, 2), 4);
    const criticRoles = [
      ['Evidence auditor', 'Ты forensic fact-checker. Ищи unsupported claims, неверные цитаты и места, где evidence не поддерживает вывод.'],
      ['Adversarial reviewer', 'Ты adversarial reviewer. Ищи противоречия, альтернативные объяснения, selection bias, stale data и missing viewpoints.'],
      ['Red-team analyst', 'Ты red-team analyst. Попробуй опровергнуть самые сильные выводы, найди missing evidence и failure cases.'],
      ['Method reviewer', 'Ты method reviewer. Оцени качество поисковой стратегии, разнообразие источников, sampling bias и достаточность глубины исследования.']
    ].slice(0, requestedRounds);
    const agentWaveMs = Date.now() - agentStarted;
    const criticStarted = Date.now();
    const critics = await Promise.all(criticRoles.map(([label, system]) => callLLM({
      system: `${system} ${SKILLS.adversarial} ${SKILLS.evidence_first}`,
      prompt: `Запрос: ${query}\n\nAGENT MEMOS:\n${agentPack}\n\nEVIDENCE:\n${evidence}\n\nПроведи audit: ${label}.`,
      kiloKey, openRouterKey, maxTokens: 2200
    })));
    const criticWaveMs = Date.now() - criticStarted;
    const criticPack = critics.map((r, i) => `### Audit ${i + 1}\n${r.text || 'LLM unavailable.'}`).join('\n\n');

    const finalStarted = Date.now();
    const final = await callLLM({
      system: `Ты senior research synthesizer. ${SKILLS.synthesis} ${SKILLS.evidence_first}`,
      prompt: `Сделай финальный research report по запросу: ${query}.\n\nСтруктура обязательна:\n1. Executive summary\n2. Key findings\n3. Evidence & sources\n4. Points of disagreement\n5. Confidence map (High/Medium/Low)\n6. What is still unknown\n7. Practical implications\n\nAGENT MEMOS:\n${agentPack}\n\nCRITICAL AUDITS:\n${criticPack}\n\nEVIDENCE:\n${evidence}`,
      kiloKey, openRouterKey, maxTokens: 3600
    });

    const finalMs = Date.now() - finalStarted;
    const mode = final.mode !== 'web-only'
      ? final.mode
      : (critics.find(x => x.mode !== 'web-only')?.mode || agentResults.find(x => x.mode !== 'web-only')?.mode || 'web-only');
    const synthesis = sanitizeCitations(final.text || fallbackSynthesis(query, evidenceSources, AGENTS.map((a, i) => ({ ...a, text: agentResults[i].text })), critics.map(x => x.text)), evidenceSources);

    const totalMs = Date.now() - started;
    const searchMs = readStarted - searchStarted;
    return json(res, 200, {
      query,
      rounds: requestedRounds,
      generatedAt: new Date().toISOString(),
      mode,
      pipeline: ['planning', '5+ search hops', 'source ranking', 'deep-read', 'second-hop links', '3 independent agents', `${requestedRounds} adversarial audits`, 'final synthesis'],
      timing: { searchMs, readMs, agentWaveMs, criticWaveMs, finalMs, totalMs },
      search: {
        provider: `${tavilyKey ? 'Tavily Advanced' : 'Jina Search + DuckDuckGo fallback'} + Jina Reader${browserResult?.output ? ' + Browser Use lane' : ''}`,
        queries: allQueries,
        sources: evidenceSources.map(s => ({ id: s.id, title: s.title, url: s.url, domain: s.domain, deepRead: !!s.deepRead, quality: s.quality, published: s.published || null }))
      },
      agents: AGENTS.map((a, i) => ({ name: a.name, role: a.role, content: agentResults[i].text })),
      audits: critics.map(r => r.text),
      jury: criticPack,
      synthesis,
      stats: {
        searchQueries: allQueries.length,
        deepReadSources: evidenceSources.filter(s => s.deepRead).length,
        secondHopSources: secondHop.length,
        llmAgents: agentResults.filter(r => r.mode !== 'web-only').length,
        llmAudits: critics.filter(r => r.mode !== 'web-only').length,
        criticRounds: requestedRounds,
        browserUse: !!browserResult?.output,
        llmFinal: final.mode !== 'web-only'
      }
    });
  } catch (err) {
    console.error(err);
    return json(res, 500, { error: err?.message || 'Research failed' });
  }
};
