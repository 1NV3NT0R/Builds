// Lightweight Agent-Skills style prompt modules.
// No framework/runtime dependency: skills are plain data that can evolve independently.
module.exports = {
  evidence_first: `EVIDENCE-FIRST: отделяй факт от inference; проверяй свежесть; ставь [S#] рядом с конкретными утверждениями; не выдумывай источники.`,
  browser_research: `BROWSER RESEARCH: начинай с нескольких независимых поисковых направлений; читай найденные страницы; следуй ссылкам на первичные материалы; ищи данные, которые могут опровергнуть первоначальный вывод.`,
  adversarial: `ADVERSARIAL: активно ищи противоречия, selection bias, stale data, missing viewpoints и альтернативные объяснения.`,
  synthesis: `SYNTHESIS: сначала сведи evidence и disagreement, затем делай выводы; неизвестное маркируй явно; не повышай confidence без достаточной опоры.`
};
