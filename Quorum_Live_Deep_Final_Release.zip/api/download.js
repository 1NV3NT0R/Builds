const { Document, Packer, Paragraph, TextRun, HeadingLevel } = require('docx');

function json(res, code, body) {
  res.statusCode = code;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.end(JSON.stringify(body));
}

function addMarkdown(children, text) {
  for (const raw of String(text || '').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) { children.push(new Paragraph({ text: '' })); continue; }
    if (/^###\s+/.test(line)) children.push(new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun(line.replace(/^###\s+/, ''))] }));
    else if (/^##\s+/.test(line)) children.push(new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(line.replace(/^##\s+/, ''))] }));
    else if (/^#\s+/.test(line)) children.push(new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(line.replace(/^#\s+/, ''))] }));
    else if (/^-\s+/.test(line)) children.push(new Paragraph({ text: line.replace(/^-\s+/, '• ') }));
    else children.push(new Paragraph({ children: [new TextRun(line)] }));
  }
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return json(res, 405, { error: 'POST only' });
  try {
    const report = req.body || {};
    const children = [];
    children.push(new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun({ text: 'Кворум Live — Deep Research', bold: true })] }));
    children.push(new Paragraph({ children: [new TextRun({ text: `Запрос: ${String(report.query || '')}`, italics: true })] }));
    children.push(new Paragraph({ text: `Дата: ${new Date().toLocaleString('ru-RU')} · Режим: ${report.mode || 'web-only'}` }));
    children.push(new Paragraph({ text: '' }));
    addMarkdown(children, report.synthesis || '');
    children.push(new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun('Источники')] }));
    for (const s of (report.search?.sources || [])) children.push(new Paragraph({ text: `[${s.id}] ${s.title} — ${s.url}` }));
    const doc = new Document({ sections: [{ children }] });
    const buffer = await Packer.toBuffer(doc);
    const filename = `Quorum_Live_${Date.now()}.docx`;
    res.statusCode = 200;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Cache-Control', 'no-store');
    res.end(buffer);
  } catch (err) {
    console.error(err);
    json(res, 500, { error: err?.message || 'DOCX generation failed' });
  }
};
