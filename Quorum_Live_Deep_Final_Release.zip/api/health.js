function json(res, code, body) {
  res.statusCode = code;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(body));
}

module.exports = async (_req, res) => {
  json(res, 200, {
    ok: true,
    service: 'quorum-live',
    runtime: 'vercel-node',
    capabilities: {
      jinaSearch: !!process.env.JINA_API_KEY,
      tavilySearch: !!process.env.TAVILY_API_KEY,
      kilo: !!(process.env.KILO_JWT || process.env.KILO_API_KEY),
      openRouter: !!process.env.OPENROUTER_API_KEY,
      browserUse: !!process.env.BROWSER_USE_API_KEY,
      docx: true
    }
  });
};
